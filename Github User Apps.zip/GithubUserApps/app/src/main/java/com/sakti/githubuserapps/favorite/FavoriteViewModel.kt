package com.sakti.githubuserapps.favorite

import android.app.Application
import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.sakti.githubuserapps.database.UserFavorite
import com.sakti.githubuserapps.repository.UserFavoriteRespository

class FavoriteViewModel(application: Application) : ViewModel() {
    private val userFavoriRepository: UserFavoriteRespository = UserFavoriteRespository(application)
    fun getFavoriteUsers(): LiveData<List<UserFavorite>> = userFavoriRepository.getFavoriteUsers()
}